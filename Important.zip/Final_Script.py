#For all the schemas in RC Document in json format

import json
from deepdiff import DeepDiff
from pprint import pprint
import difflib
import sys
from urllib.request import urlopen


class Logger():
    def __init__(self):
        self.terminal = sys.stdout
        self.log = open("Schema_logfile.txt", "a")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        #this flush method is needed for python 3 compatibility.
        #this handles the flush command by doing nothing.
        #you might want to specify some extra behavior here.
        pass

sys.stdout = Logger()

baseUrl ="http://docs.ruckuswireless.com/ruckus-cloud/wifi-ns-"#210311.json
version=input("Enter the First version:")
url_version=baseUrl+version+".json"
print(url_version)
response = urlopen(url_version)
data_json = json.loads(response.read())
compo=data_json['components']
scheme=compo['schemas']
lst=[]             #lst has all the API(S) of 210311(First Version) stored in it.
for x in scheme:   #x is all the API(S) of 210311(First Version)
    lst.append(x)
print("API Schemas present in",version,lst)

with open('demo.json','w+') as f:
    json.dump(scheme,f,indent=4)

baseUrl1 ="http://docs.ruckuswireless.com/ruckus-cloud/wifi-ns-"#210412.json
version1=input("Enter the Second version:")
url_version1=baseUrl1+version1+".json"
print(url_version1)
response1 = urlopen(url_version1)
data_json1 = json.loads(response1.read())
compo1=data_json1['components']
scheme1=compo1['schemas']
lst1=[]                     #lst has all the API(S) of 210412(Second Version) stored in it
for y in scheme1:           #y is all the API(S) of 210412(Second Version)
    lst1.append(y)
print("API Schemas present in",version1,lst1,"\n")

with open('demo1.json','w+') as f1:
    json.dump(scheme1,f1,indent=4)

print("---------- Missing API(s), Newly added API(s), Common API(s) ----------\n")

lst5 = set(lst) - set(lst1)    #lst5 has all the missing API(S) in 2103 but present in 2104.
print("Missing API Schemas in",version,"but present in",version1, sorted(lst5))

lst2 = set(lst1) - set(lst)    #lst2 has all the newly added API(S) in 2104.
print("Newly added API Schemas in",version1, sorted(lst2))


set1=set(lst)
set2=set(lst1)
set3=set1.intersection(set2)
lst3=list(set3)                #lst3 has common API(S) present in both the versions.
print("Common API schemas present in",version,"and",version1,sorted(lst3))

for api in sorted(lst3):

    api_2103=json.dumps(scheme[api])
    api_2104=json.dumps(scheme1[api])
    json1_dict = json.loads(api_2103)
    json2_dict = json.loads(api_2104)

    with open('First_version.txt', 'a+') as filepd:
        json.dump(json1_dict, filepd, indent=2)

    with open('Second_version.txt', 'a+') as filepd1:
        json.dump(json2_dict, filepd1, indent=2)


    try:
        json1_dict = json.loads(api_2103)
        json2_dict = json.loads(api_2104)
        print("Valid Json Format of:",api)
    except Exception as e:
        print(e)
        print("InValid Json Format of:",api)

    def sorting(item):
         if isinstance(item, dict):
             return sorted((key, sorting(values)) for key, values in item.items())
         if isinstance(item, list):
             return sorted(sorting(x) for x in item)
         else:
             return item

    sort_elements = (sorting(json1_dict) == sorting(json2_dict))
    sort_order = (sorted(json1_dict.items()) == sorted(json2_dict.items()))
    ddiff = DeepDiff(sorting(json1_dict), sorting(json2_dict), ignore_order=True, report_repetition=True)
    sort_len = (len(json1_dict) == len(json2_dict))

    if(sort_len==True) and (ddiff=={}) and (sort_elements==True) and (sort_order):
        print(" Conditions are True schemas match")
    else:
        print("Conditions are False schemas does not match")
        if (sort_len == False):

            print("Common API Schema from",version,"and",version1,"are having Different Number of Elements")


        if (sort_order == False):

            print("Common API Schema from",version,"and",version1,"are having Elements in the Different Order")


        if (ddiff == {}):

            print("Common API Schema from",version,"and",version1,"are having Similar Elements")

        else:
            print("Common API Schema from",version,"and",version1,"are having Different Elements")

        if (sort_len == False):

            print("Common API Schema from",version,"and",version1," are having Different Number of Keys")


        diff=DeepDiff(json1_dict,json2_dict)
        print("Newly added values in",version1,":",api,"=>")
        pprint(diff,indent=2)

        diff_values = diff.values()
        diff_keys = list(diff.keys())
        diff_list= list(diff_values)

        print("Different key, value changes in",version,"and",version1,":", diff_list)
        for i in range(len(diff_list)):
            if (i == 0):
                print(version1, "------------", version)
                print(diff_keys[0])
                print(diff_list[i],"------")
            if (i == 1):
                print(version1, "------------", version)
                print(diff_keys[1])
                print(diff_list[i],"------")
            if (i == 2):
                print(version1, "------------", version)
                print(diff_keys[2])
                print(diff_list[i],"------")

first_file = "First_version.txt"
second_file = "Second_Version.txt"
first_file_json = open(first_file).readlines()
second_file_json = open(second_file).readlines()
difference = difflib.HtmlDiff().make_file(first_file_json, second_file_json, first_file, second_file)
difference_report = open("Schema_difference.html", "w")
difference_report.write(difference)
difference_report.close()









